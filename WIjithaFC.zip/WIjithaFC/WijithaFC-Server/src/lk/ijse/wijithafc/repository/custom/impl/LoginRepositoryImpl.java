/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lk.ijse.wijithafc.repository.custom.impl;

import java.io.Serializable;
import lk.ijse.wijithafc.entity.Login;
import lk.ijse.wijithafc.repository.SuperRepositoryImpl;
import lk.ijse.wijithafc.repository.custom.LoginRepository;

/**
 *
 * @author ASUS
 */
public class LoginRepositoryImpl extends SuperRepositoryImpl<Login, String> implements LoginRepository{
    
}
